# Codes complets – Stockage ferrailles AT1 (SNCF Réseau)

| Dossier | Contenu |
| --- | --- |
| 1_site_interne_sources | Site interne en fichiers séparés : index.html, css/style.css, js/app.js, données (js/donnees), bibliothèques (js/lib), images (img), sync-config.js |
| 2_site_fournisseurs_sources | Site fournisseurs en fichiers séparés (même structure, sans données de stock) |
| 3_github | Un seul fichier index.html par site, tout compris : à déposer tel quel dans chaque dépôt GitHub |
| 4_tableur_partage | Script Google (Code.gs), classeur à importer dans Google Sheets et mode d'emploi |

Les fichiers séparés (dossiers 1 et 2) servent à lire ou modifier le code : pour les mettre en ligne, il faut garder les sous-dossiers css, js et img.
Pour GitHub, le plus simple est le fichier unique du dossier 3.
