# Données partagées avec un Google Sheet – mode d'emploi

Objectif : que les mouvements de stock, les seuils et le plan de rangement soient communs à tous les utilisateurs, sur tous les appareils,
sans dépendre d'un autre service que ton Google Sheet. Le site continue de fonctionner seul (données locales) si tu ne configures rien.

## 1. Mise en place (10 minutes, une seule fois)

1. Dépose le fichier `Stockage_AT1_donnees_partagees.xlsx` dans Google Drive, ouvre-le avec Google Sheets, puis **Fichier > Enregistrer au format Google Sheets** (obligatoire pour pouvoir ajouter le script). Il contient déjà les onglets Mouvements et Donnees, un onglet Lisez-moi et un registre Utilisateurs à remplir. À défaut, un tableur vide convient aussi : le script crée les onglets tout seul.
2. Dans la version Google Sheets : menu **Extensions > Apps Script**. Supprime le code présent, colle tout le contenu du fichier `Code.gs`.
3. En haut du script, remplace les deux codes d'accès (ils remplacent les mots CHANGEZ-MOI) :
   - `CODE_EDITION` : pour les personnes qui saisissent les mouvements et modifient le plan ;
   - `CODE_LECTURE` : pour les personnes qui consultent seulement.
   Choisis des codes d'au moins 8 caractères, différents l'un de l'autre.
4. Clique sur **Déployer > Nouveau déploiement**. Clique sur la roue dentée, choisis **Application Web**. Réglages :
   - Description : « Stockage AT1 » ;
   - Exécuter en tant que : **Moi** ;
   - Qui a accès : **Tout le monde**.
5. Clique sur **Déployer**. Google demande d'autoriser le script : choisis ton compte, clique sur « Paramètres avancés », puis « Accéder à … (non sécurisé) », puis « Autoriser ». Ce message est normal pour un script personnel.
6. Copie l'**URL de l'application Web** (elle se termine par `/exec`).
7. Vérification : ouvre cette URL dans un navigateur. Le message « Stockage ferrailles AT1 : service actif. » doit s'afficher.

## 2. Brancher le site

Deux possibilités :
- **Pour tous les utilisateurs d'un coup** : colle l'URL entre les guillemets de `url: ""`, puis redépose le fichier :
  - version GitHub ou fichier unique : tout en haut du fichier `index.html`, ligne `window.AT1_SYNC = … { url: "", code: "" }` (ouvrir le fichier avec le Bloc-notes) ;
  - version en dossiers (PC) : fichier `sync-config.js`.
- **Appareil par appareil** : en haut de la page **Gestion du stock**, bandeau des données, clique sur « Relier à un tableau partagé » et colle l'URL.

**Connexion automatique (le plus simple)** : écris aussi le code dans `sync-config.js` : `window.AT1_SYNC = { url: "…/exec", code: "ton code" };`
Tout le monde est alors connecté automatiquement, sans rien saisir. À réserver à un site rangé dans un dossier interne (OneDrive, Teams) :
toute personne qui a les fichiers peut écrire dans le stock, et il n'y a plus de différence entre éditeurs et lecteurs. Ne jamais le faire sur un site public.

**Sinon**, chaque utilisateur saisit son code d'accès dans ce bandeau, en haut de la page **Gestion du stock**, et clique sur « Se connecter ». Le code est gardé sur l'appareil : il n'est demandé qu'une fois.
- Code d'édition : saisie des mouvements, corrections, modification du plan et des seuils.
- Code de lecture : consultation seule.

Le bandeau indique « connecté en édition » ou « connecté en lecture » et l'heure de la dernière mise à jour. Le site vérifie le tableau toutes les 20 secondes, uniquement quand la page est affichée. Hors connexion, il réessaie tout seul.

## 3. Reprendre les données existantes

1. Sur l'ancienne version, clique sur « Sauvegarder » (bandeau en haut de la page Gestion du stock, ou carte Sauvegarde des données sur une version plus ancienne).
2. Ouvre la nouvelle version, connecte-toi avec le **code d'édition**.
3. Dans le bandeau en haut de la page Gestion du stock, clique sur « Restaurer » et choisis le fichier. Le plan, les seuils et tous les mouvements sont envoyés au tableur en une fois.

À la première connexion avec le code d'édition sur un tableur vide, le plan de rangement affiché sur ton écran est enregistré dans le tableur.

## 4. Vérification après la mise en place (5 minutes)

- Connecte-toi en édition sur un PC, saisis un mouvement de test : une ligne apparaît dans la feuille **Mouvements** du tableur.
- Ouvre le site sur un téléphone avec le code de lecture : le mouvement apparaît en moins de 30 secondes, sans bouton de saisie.
- Corrige puis supprime ton mouvement de test depuis « Derniers mouvements ».

## 5. Bon à savoir

- **Ne modifie pas le tableur à la main** : les feuilles sont écrites par le site. Pour corriger, utilise le bouton « Corriger » de « Derniers mouvements ». Tu peux en revanche ouvrir le tableur pour consulter et exporter en Excel (Fichier > Télécharger).
- **Sauvegarde** : une fois le tableur connecté, les données sont dans le tableur, et Google garde l'historique (Fichier > Historique des versions). Les boutons « Sauvegarder » et « Restaurer » ne restent visibles que tant que le tableur est vide, pour le premier transfert des données. Pour une copie de sécurité, télécharge le tableur en Excel de temps en temps (Fichier > Télécharger).
- **Changer un code** : modifie-le dans le script, puis **Déployer > Gérer les déploiements > crayon > Version : Nouvelle version > Déployer**. L'URL ne change pas. Les appareils concernés devront ressaisir leur code.
- **Modifier le script plus tard** : même démarche, avec une « nouvelle version » du déploiement existant. Un « nouveau déploiement » créerait une nouvelle URL.
- **Limites de Google** : l'usage gratuit d'Apps Script est limité chaque jour. C'est largement suffisant pour une petite équipe avec ce fonctionnement. Si la limite était atteinte, le site afficherait « Hors connexion » puis reprendrait le lendemain.
- **Sécurité** : l'URL est dans le code du site. Si le site est public, toute personne qui la trouve peut l'appeler, mais elle ne peut rien lire ni écrire sans un code valide. Garde les codes confidentiels. Le propriétaire du tableur voit toutes les données.
- **QR codes des étiquettes** : ils contiennent l'adresse du site. Imprime-les une fois l'adresse définitive connue.
