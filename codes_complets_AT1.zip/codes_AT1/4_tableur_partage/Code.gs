/**
 * Stockage ferrailles AT1 – données partagées dans un Google Sheet
 *
 * Ce script transforme le Google Sheet qui le contient en petite base de données pour le site :
 *   - feuille « Mouvements » : un mouvement de stock par ligne (lisible, exportable en Excel) ;
 *   - feuille « Donnees »    : plan de rangement et seuils de stock (ne pas modifier à la main).
 *
 * Mise en place : voir MODE_EMPLOI_donnees_partagees.md
 *   1. Choisir deux codes d'accès ci-dessous (ils remplacent les mots « CHANGEZ-MOI »).
 *   2. Déployer > Nouveau déploiement > Application Web > Exécuter en tant que : Moi > Accès : Tout le monde.
 *   3. Copier l'adresse du déploiement (elle se termine par /exec) dans le site.
 */

// ====== À MODIFIER : codes d'accès ======
const CODE_EDITION = "CHANGEZ-MOI-EDITION";   // pour les personnes qui saisissent les mouvements et modifient le plan
const CODE_LECTURE = "CHANGEZ-MOI-LECTURE";   // pour les personnes qui consultent seulement
// ========================================

const FEUILLE_MVT = "Mouvements", FEUILLE_DOC = "Donnees";
const TETE_MVT = ["id", "at", "Date", "Référence", "Type", "Quantité (m)", "Par", "Commentaire", "json"];
const TETE_DOC = ["chemin", "partie", "texte"];
const TYPES = { E: "Entrée", S: "Sortie", A: "Inventaire" };
const DOCS_OK = ["plan/etat", "stockcfg/seuils", "stockcfg/base"];
const TRANCHE = 40000;   // une cellule Google Sheets accepte 50 000 caractères au maximum

function doGet() { return ContentService.createTextOutput("Stockage ferrailles AT1 : service actif."); }

function doPost(e) {
  let sortie;
  try { sortie = traiter_(JSON.parse((e && e.postData && e.postData.contents) || "{}")); }
  catch (err) { sortie = { ok: false, err: String((err && err.message) || err) }; }
  return ContentService.createTextOutput(JSON.stringify(sortie)).setMimeType(ContentService.MimeType.JSON);
}

function role_(code) {
  if (CODE_EDITION.indexOf("CHANGEZ") === 0 || CODE_LECTURE.indexOf("CHANGEZ") === 0) throw new Error("codes non configurés dans le script");
  if (code && code === CODE_EDITION) return "edition";
  if (code && code === CODE_LECTURE) return "lecture";
  Utilities.sleep(1000);   // ralentit les essais de codes
  return null;
}

function traiter_(req) {
  const role = role_(String(req.code || ""));
  if (!role) return { ok: false, err: "code" };
  const a = req.action;
  if (a === "auth") return { ok: true, role: role };
  if (a === "ver") return { ok: true, v: version_() };
  if (a === "snap") return instantane_();
  if (role !== "edition") return { ok: false, err: "droits" };
  const verrou = LockService.getScriptLock(); verrou.waitLock(25000);
  try {
    let r = {};
    if (a === "add") { r.id = ajouterMvt_(req.mvt); }
    else if (a === "setmvt") { modifierMvt_(String(req.id), req.mvt); }
    else if (a === "delmvt") { supprimerMvt_(String(req.id)); }
    else if (a === "setdoc") { verifierChemin_(req.path); ecrireDoc_(req.path, req.data); }
    else if (a === "deldoc") { verifierChemin_(req.path); supprimerDoc_(req.path); }
    else if (a === "restore") { restaurer_(req.mvts || [], req.seuils || {}); }
    else return { ok: false, err: "action inconnue" };
    r.ok = true; r.v = incrementer_();
    return r;
  } finally { verrou.releaseLock(); }
}

// ---------- version (permet au site de savoir, très vite, si quelque chose a changé) ----------
function version_() { return PropertiesService.getScriptProperties().getProperty("v") || "0"; }
function incrementer_() { const p = PropertiesService.getScriptProperties(), v = String(Number(p.getProperty("v") || "0") + 1); p.setProperty("v", v); return v; }

// ---------- feuilles ----------
function feuille_(nom, tete) {
  const ss = SpreadsheetApp.getActiveSpreadsheet(); let sh = ss.getSheetByName(nom);
  if (!sh) { sh = ss.insertSheet(nom); sh.appendRow(tete); sh.setFrozenRows(1); }
  return sh;
}
const txt_ = v => { const s = String(v == null ? "" : v); return /^[=+\-@]/.test(s) ? "'" + s : s; };   // évite qu'un texte saisi soit interprété comme une formule
const idNouveau_ = () => "m" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

// ---------- mouvements de stock ----------
function verifierMvt_(m) {
  if (!m || typeof m.c !== "string" || !TYPES[m.t] || typeof m.qty !== "number" || !isFinite(m.qty) || typeof m.at !== "number") throw new Error("mouvement invalide");
  if (JSON.stringify(m).length > 4000) throw new Error("mouvement trop long");
}
function ligneMvt_(m) { return [m.id, m.at, txt_(m.d), txt_(m.c), TYPES[m.t], m.qty, txt_(m.par), txt_(m.note), JSON.stringify(m)]; }
function ajouterMvt_(m) { verifierMvt_(m); m.id = idNouveau_(); feuille_(FEUILLE_MVT, TETE_MVT).appendRow(ligneMvt_(m)); return m.id; }
function numeroLigne_(sh, id) {
  const n = sh.getLastRow() - 1; if (n < 1) return 0;
  const ids = sh.getRange(2, 1, n, 1).getValues();
  for (let i = 0; i < n; i++) if (String(ids[i][0]) === id) return i + 2;
  return 0;
}
function modifierMvt_(id, m) {
  verifierMvt_(m); const sh = feuille_(FEUILLE_MVT, TETE_MVT), l = numeroLigne_(sh, id); if (!l) throw new Error("mouvement introuvable");
  m.id = id; sh.getRange(l, 1, 1, 9).setValues([ligneMvt_(m)]);
}
function supprimerMvt_(id) { const sh = feuille_(FEUILLE_MVT, TETE_MVT), l = numeroLigne_(sh, id); if (!l) throw new Error("mouvement introuvable"); sh.deleteRow(l); }

// ---------- documents (plan de rangement, seuils) : texte JSON découpé en tranches ----------
function verifierChemin_(p) { if (DOCS_OK.indexOf(p) < 0) throw new Error("document non autorisé"); }
function lignesDoc_() { const sh = feuille_(FEUILLE_DOC, TETE_DOC), n = sh.getLastRow() - 1; return { sh: sh, n: n, rows: n > 0 ? sh.getRange(2, 1, n, 3).getValues() : [] }; }
function lireDoc_(chemin) {
  const rows = lignesDoc_().rows.filter(r => r[0] === chemin).sort((x, y) => Number(x[1]) - Number(y[1]));
  if (!rows.length) return null;
  try { return JSON.parse(rows.map(r => String(r[2]).slice(1)).join("")); } catch (e) { return null; }
}
function reecrireDocs_(rows, ancienNombre, sh) {
  if (ancienNombre > 0) sh.getRange(2, 1, ancienNombre, 3).clearContent();
  if (rows.length) sh.getRange(2, 1, rows.length, 3).setValues(rows);
}
function ecrireDoc_(chemin, data) {
  const d = lignesDoc_(), rows = d.rows.filter(r => r[0] !== chemin), t = JSON.stringify(data);
  for (let i = 0, p = 0; i < t.length; i += TRANCHE, p++) rows.push([chemin, p, "J" + t.slice(i, i + TRANCHE)]);   // « J » : empêche toute interprétation du texte par le tableur
  reecrireDocs_(rows, d.n, d.sh);
}
function supprimerDoc_(chemin) { const d = lignesDoc_(); reecrireDocs_(d.rows.filter(r => r[0] !== chemin), d.n, d.sh); }

// ---------- restauration complète d'une sauvegarde ----------
function restaurer_(mvts, seuils) {
  const sh = feuille_(FEUILLE_MVT, TETE_MVT), n = sh.getLastRow() - 1;
  if (n > 0) sh.getRange(2, 1, n, 9).clearContent();
  const lignes = mvts.map(m => { verifierMvt_(m); m.id = idNouveau_(); return ligneMvt_(m); });
  if (lignes.length) sh.getRange(2, 1, lignes.length, 9).setValues(lignes);
  supprimerDoc_("stockcfg/base"); ecrireDoc_("stockcfg/seuils", { s: seuils, at: Date.now() });
}

// ---------- lecture complète ----------
function instantane_() {
  const sh = feuille_(FEUILLE_MVT, TETE_MVT), n = sh.getLastRow() - 1, mvts = [];
  if (n > 0) sh.getRange(2, 1, n, 9).getValues().forEach(r => { try { const m = JSON.parse(r[8]); m.id = String(r[0]); mvts.push(m); } catch (e) {} });
  return { ok: true, v: version_(), plan: lireDoc_("plan/etat"), seuils: lireDoc_("stockcfg/seuils"), base: lireDoc_("stockcfg/base"), mvts: mvts };
}
